ReadMe (well, if you feel like)     
                       

Here are some fonts I made up.
Hope you like them, and if you happenned to use it I'd be just pleased with it.
Also I appreciate any feedback, any critics, don't be too rude is all...
For those really curious, here is what I had in mind creating these fonts.

SoleaMM was my first attempt to make a complete font, and I as feared the process to be too simple I decided to start it MultipleMaster. Good trick, it was NOT too simple. The starting idea was to catch the simplicity and modern/antique feeling of some Roman grafitti (maybe from Pompei) I once saw in a book. This kind of starting idea usually lead to a result with a completely different feeling, which is the case here. Though, I like the font, especialy for big short headlines, used wide-spaced.

Brouss is a quick'n'dirty'n'happy brush work. 

LondonMM tries to be both humanistic and geometrical, and probably fails in both. It should be usable, though, at least if I was better at fine-tuning the kernings... 

LambadaDexter is the only font I ever get paid to design! So I can claim to be a pro! Gee!
If you find it cartoony, no wonder, it was for a french cartoon network.

Fonitek is intended for kidsbooks, but if you feel like using it for a Wittgenstein reprint, you're the boss.

�fb2001, but use and distribute freely, as long as you don't charge for it.
You can post messages on newsgroup alt.binaries.mac.fonts
You can E-mail me: fbruel@mac.com 
                                                                         